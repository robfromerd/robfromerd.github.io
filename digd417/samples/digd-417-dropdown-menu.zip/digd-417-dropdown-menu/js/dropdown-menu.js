jQuery(document).ready(function($){
	//Add + to Mobile menu items that have children
	$('<span class="control"><i class="fa fa-plus theControl"></i></span>').insertBefore('#main-menu ul.dropdown-menu');
	if(innerWidth < 768 || $(window).resize(innerWidth < 768)){
		//Mobile Expand Menu Click Function
		$('.control').click(function(){
			var mobmenu = $(this).next('.dropdown-menu');
			if(mobmenu.css("display") == "none"){
			mobmenu.slideToggle('fast');
			$(this).html('<i class="fa fa-minus theControl"></i>');
			}else{
			mobmenu.slideToggle();
			$(this).html('<i class="fa fa-plus theControl"></i>');
			}
		}); //End Mobile Click Function
	}else{
	}; //End Mobile Query for Dropdown
	//Reset Mobile Dropdown so hover works if Window is resized to Desktop
		$(window).resize(function(){
			if(innerWidth >= 768){
			$('#main-menu ul.dropdown-menu').css("display", "");
			}
		});
});//End Ready



jQuery(function($){
	const $dropdown = $(".dropdown");
const $dropdownToggle = $(".dropdown-toggle");
const $dropdownMenu = $(".dropdown-menu");
const showClass = "show";

$(window).on("load resize", function() {
  if (this.matchMedia("(min-width: 768px)").matches) {
    $dropdown.hover(
      function() {
        const $this = $(this);
        $this.addClass(showClass);
        $this.find($dropdownToggle).attr("aria-expanded", "true");
        $this.find($dropdownMenu).addClass(showClass);
      },
      function() {
        const $this = $(this);
        $this.removeClass(showClass);
        $this.find($dropdownToggle).attr("aria-expanded", "false");
        $this.find($dropdownMenu).removeClass(showClass);
      }
    );
  } else {
    $dropdown.off("mouseenter mouseleave");
  }
});

    });
	