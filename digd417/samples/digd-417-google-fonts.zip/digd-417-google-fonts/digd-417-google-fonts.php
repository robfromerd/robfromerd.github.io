<?php
/*
Plugin Name: Digd-417 Google Fonts
Plugin URI:  https://robertgoldberg.net
Description: This plugin provides an options page to enqueue Google Fonts.
Version:     1.0
Author:      Rob Goldberg
Author URI:  https://robertgoldberg.net
License:     GPL2 etc
License URI: https://www.gnu.org/licenses/

Copyright 2020 Rob Goldberg (robert.goldberg@jefferson.edu)
Digd-417 Google Fonts is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Digd-417 Google Fonts is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Digd-417 Google Fonts. If not, see (https://www.gnu.org/licenses/).
*/
function rg_acf_options_page() {
	if ( ! function_exists( 'acf_add_options_page' ) )
		return;

	acf_add_options_page( array( 
		'title'      => 'Site Options',
		'capability' => 'manage_options',
	) );
}
add_action( 'init', 'rg_acf_options_page' );

add_action( 'wp_enqueue_scripts', 'googlefonts_enqueue_styles' );
function googlefonts_enqueue_styles() {
$the_google_font = get_field( 'google_fonts', 'options' );
wp_enqueue_style( 'google-fonts', $the_google_font, false ); 
}

if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array(
	'key' => 'group_5f8b5305355db',
	'title' => 'Google Fonts',
	'fields' => array(
		array(
			'key' => 'field_5f8b5316d58c8',
			'label' => 'Google Fonts',
			'name' => 'google_fonts',
			'type' => 'url',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => '',
			'placeholder' => '',
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'options_page',
				'operator' => '==',
				'value' => 'acf-options-site-options',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => true,
	'description' => '',
));

endif;