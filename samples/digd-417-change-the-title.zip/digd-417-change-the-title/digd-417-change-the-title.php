<?php
/*
Plugin Name: Digd-417 Filter Sale Titles
Plugin URI:  https://robertgoldberg.net
Description: This plugin adds On Sale to products categorized as Sale.
Version:     1.1
Author:      Rob Goldberg
Author URI:  https://robertgoldberg.net
License:     GPL2 etc
License URI: https://www.gnu.org/licenses/

Copyright 2020 Rob Goldberg (robert.goldberg@jefferson.edu)
(Plugin Name) is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Filter Sale Titles is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with (Plugin Name). If not, see (https://www.gnu.org/licenses/).
*/

remove_action('woocommerce_single_product_summary','woocommerce_template_single_title',5);
add_action('woocommerce_single_product_summary', 'woocommerce_my_single_title',5);

if (! function_exists( 'woocommerce_my_single_title'  ) ) {
   function woocommerce_my_single_title() {
   if (has_term( 'sale', 'product_cat' ) ){
?>
            <h1 itemprop="name" class="product_title entry-title"><span class="highlight">On Sale:</span> <span><?php the_title(); ?></span></h1>
<?php
		}
    }
}