<?php
/*
Plugin Name: Digd-417 Custom Permissions
Plugin URI:  https://robertgoldberg.net
Description: This plugin allows the editor to use the customizer but not change themes.
Version:     1.0
Author:      Rob Goldberg
Author URI:  https://robertgoldberg.net
License:     GPL2 etc
License URI: https://www.gnu.org/licenses/

Copyright 2020 Rob Goldberg (robert.goldberg@jefferson.edu)
Digd-417 Custom Permissions is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Digd-417 Custom Permissions is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Digd-417 Custom Permissions. If not, see (https://www.gnu.org/licenses/).
*/
//  function needed to hide 
add_action('admin_head', 'rcg_hide_menu', 999);

function rcg_hide_menu() {
$role_object = get_role('editor');
// have we done this before, if not ...
	if (!$role_object->has_cap( 'edit_theme_options' ) ) {
	$role_object->add_cap( 'edit_theme_options' );
	}
$role_object = get_role('shop_manager');
// have we done this before, if not ...
	if ($role_object->has_cap( 'edit_theme_options' ) ) {
	$role_object->remove_cap( 'edit_theme_options' );
	}	
	// Current user
$user = wp_get_current_user();
	// If is not Admin
	if (!$user->has_cap('edit_users')){
	// Hide theme selection page
	remove_submenu_page( 'themes.php', 'themes.php' );
	// Hide widgets page
	remove_submenu_page( 'themes.php', 'widgets.php' );
	};
}
// Function needed to remove the "Background Image Panel" from customizer
add_action( 'customize_register', 'rcg_customize_register',50 );

function rcg_customize_register( $wp_customize ) {
  // If our current user can't manage options they are not an admin and so we remove the background image panel from the customizer
	if ( ! current_user_can( 'manage_options' ) ) {
  	$wp_customize->remove_section( 'background_image');
	}
}
add_action( 'admin_init', 'rcg_debug_admin_menu' );

// How we get the correct index number of the nested array to unset 
function rcg_debug_admin_menu() {

//echo '<pre>' . print_r( $GLOBALS[ 'submenu' ], TRUE) . '</pre>';
}

add_action('admin_init', 'rcg_remove_theme_submenus');

function rcg_remove_theme_submenus() {
   global $submenu; 
 if ( ! current_user_can( 'manage_options' ) ) {  
    unset($submenu['themes.php'][20]);
  //    remove_menu_page( 'Background' );
  }
}